const App = () => {
    const [products, setProducts] = React.useState([]);
    const [form, setForm] = React.useState({
        name: '',
        price: ''
    });

    React.useEffect(() => {
        fetchProducts();
    }, []);

    function fetchProducts() {
        fetch('/api/products')
            .then((res) => {
                if (!res.ok) {
                    throw new Error('Network response was not ok');
                }
                return res.json();
            })
            .then(data => {
                console.log('Fetched products:', data);
                setProducts(data);
            })
            .catch(error => {
                console.error('Error fetching products:', error);
            });
    }

    function handleSubmit(e) {
        e.preventDefault(); // Prevents the default form submission

        if (!form.name || !form.price) {
            return; // Return if form fields are empty
        }

        fetch('/api/products', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(form)
        })
        .then(res => res.json())
        .then(data => {
            fetchProducts();
            setForm({
                name: '',
                price: ''
            })
            // console.log(data);
            // Optionally, update the products list or reset the form
        });
    }

    function updateForm(event, field) {
        setForm({
            ...form, // Spread the existing form fields
            [field]: event.target.value // Update the specific field
        });
    }


const deleteProduct = () => {
fetch(`/api/product/ ${productId}`, {
    method: 'DELETE'
}).then((res) => res.json())
.then((data) =>{
    fetchProducts();
    console.log(data);
}) 
}

    return (
        <>
            <div className="card">
                <div className="card-header">
                    Featured
                </div>
                <div className="card-body">
                    <form onSubmit={handleSubmit}>
                        <input
                            type="text"
                            value={form.name}
                            onChange={(event) => updateForm(event, 'name')}
                            placeholder="Product name"
                            className="form-control mt-3"
                        />
                        <input
                            type="text"
                            value={form.price}
                            onChange={(event) => updateForm(event, 'price')}
                            placeholder="Product price"
                            className="form-control mt-3"
                        />
                        <button type="submit" className="btn btn-primary mt-3">Submit</button>
                    </form>
                </div>
            </div>
            <div>
                {products.length > 0 ? (
                    <ul className="list-group mt-4">
                        {products.map((product) => (
                            <li key={product.id} className="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong>{product.name}: </strong>${product.price}
                                </div>
                                <button className="btn" onClick={() => deleteProduct(product.id)}>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
                                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/>
                                        <path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/>
                                    </svg>
                                </button>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p>No products found</p>
                )}
            </div>
        </>
    );
};

ReactDOM.createRoot(document.getElementById('app')).render(<App />);
