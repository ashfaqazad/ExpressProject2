const router = require('express').Router();


// Ab ye HTML ky pages ejs ky through ho rhy hen.
// router.get('/', (req, res)=>{
//     // console.log('This is get request');
//     res.render('index', {
//      // Es tarah sy ham data server sy template engine men bhej sakty hen, aur phr usy yahan par render kr sakty hen.

//         title: 'My Home page'
//     })
//     // res.sendFile('/index.html', {root: __dirname} )
// })

// router.get('/about', (req, res)=>{
//     // console.log('This is get request');
//     res.render('about',{
//         // Es tarah sy ham data server sy template engine men bhej sakty hen, aur phr usy yahan par render kr sakty hen.
//         title: 'My About page'
//     })
//     // res.sendFile('/about.html', {root: __dirname} )
// })

// es code ky through ham kise bhi stattic file ko download krty hen:-
router.get('/download', (req, res)=>{
    // console.log('This is get request');
    res.download('/about.html', {root: __dirname} )
})




module.exports = router