const products = [
    {
        id: '1',
        name: 'Photoshop',
        price: '300'
    },
    {
        id: '2',
        name: 'Webstrom',
        price: '200'
    },
    {
        id: '3',
        name: 'Figma',
        price: '100'
    }
];

module.exports = products;
